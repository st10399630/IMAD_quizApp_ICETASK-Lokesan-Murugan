package com.example.quizapplication

import android.graphics.drawable.AnimationDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView

class MainActivity : AppCompatActivity() {


    private lateinit var result: TextView
    private lateinit var submitButton: Button
    private lateinit var button1: Button
    private lateinit var button2: Button
    private lateinit var button3: Button
    private lateinit var button4: Button
    private lateinit var button5: Button
    private lateinit var button6: Button
    private lateinit var button7: Button
    private lateinit var button8: Button
    private lateinit var button9: Button
    private lateinit var button10: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val correctAnswers = listOf("A", "B", "A","A","B")
        var score = 0
        val userSelection = "A"
        button1.setOnClickListener {
            if (userSelection == correctAnswers[1]){
                score++
            }
            button2.setOnClickListener {
                if (userSelection == correctAnswers[0]){
                    score++
                }
                button3.setOnClickListener {
                    if (userSelection == correctAnswers[0]){
                        score++
                    }
                    button4.setOnClickListener {
                        if (userSelection == correctAnswers[1]){
                            score++
                        }
                        button5.setOnClickListener {
                            if (userSelection == correctAnswers[1]){
                                score++
                            }
                            button6.setOnClickListener {
                                if (userSelection == correctAnswers[0]) {
                                    score++
                                }
                                button7.setOnClickListener {
                                    if (userSelection == correctAnswers[1]) {
                                        score++
                                    }
                                    button8.setOnClickListener {
                                        if (userSelection == correctAnswers[0]) {
                                            score++
                                        }
                                        button9.setOnClickListener {
                                            if (userSelection == correctAnswers[0]) {
                                                score++
                                            }
                                            button10.setOnClickListener {
                                                if (userSelection == correctAnswers[1]) {
                                                    score++
                                                }

                                                submitButton.setOnClickListener {
                                                    val totalScore = score
result.text="Total Score: $totalScore"


}                                               }
}                                               }
                                        }}}}}}}}}